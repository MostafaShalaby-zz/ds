﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace HTTPServer
{
    public enum RequestMethod
    {
        GET,
        POST,
        HEAD
    }

    public enum HTTPVersion
    {
        HTTP10,
        HTTP11,
        HTTP09
    }

    class Request
    {
        string[] requestLines;
        RequestMethod method;
        public string relativeURI;
        Dictionary<string, string> headerLines;

        public Dictionary<string, string> HeaderLines
        {
            get { return headerLines; }
        }

        HTTPVersion httpVersion;
        string requestString;
        string[] contentLines;

        public Request(string requestString)
        {
            this.requestString = requestString;
        }
        /// <summary>
        /// Parses the request string and loads the request line, header lines and content, returns false if there is a parsing error
        /// </summary>
        /// <returns>True if parsing succeeds, false otherwise.</returns>
        public bool ParseRequest()
        {
            bool x = true;
            //  throw new NotImplementedException();


            //TODO: parse the receivedRequest using the \r\n delimeter   
            requestLines = requestString.Split(new string[] { "\r\n" }, StringSplitOptions.None);

            // check that there is atleast 3 lines: Request line, Host Header, Blank line (usually 4 lines with the last empty line for empty content)
            if (requestLines.Length < 3)
                return false;

            // Parse Request line
            x = ParseRequestLine();
            if (x == false)
            {
                return x;
            }
            x = ValidateIsURI(relativeURI);
            if (x == false)
            {
                return x;
            }
            // Validate blank line exists
            x = ValidateBlankLine();
            if (x == false)
            {
                return x;
            }
            // Load header lines into HeaderLines dictionary
            x = LoadHeaderLines();
            if (x == false)
            {
                return x;
            }

            return x;

        }

        private bool ParseRequestLine()
        { //throw new NotImplementedException();
            bool x = true;
            String RequestLine = requestLines[0];
            String[] RequestLine_Parts = RequestLine.Split(' ');
            if (RequestLine_Parts.Length == 3)
            {
                x = true;
            }
            else
            {
                x = false;
                return x;
            }

            method = (RequestMethod)Enum.Parse(typeof(RequestMethod), RequestLine_Parts[0]);
    
            if (method == RequestMethod.GET)
            {
                x = true;
            }
            else
            {
                x = false;
                return x;
            }

            relativeURI = RequestLine_Parts[1];

            string httpvesion = RequestLine_Parts[2];

            if (httpvesion == "HTTP/1.0")
                httpVersion = HTTPVersion.HTTP10;
            else if (httpvesion == "HTTP/1.1")
                httpVersion = HTTPVersion.HTTP11;
            else if (httpvesion == "HTTP/0.9" || httpvesion == "HTTP")//If a server gets a request line with no HTTP version number, it assumes 0.9.
                httpVersion = HTTPVersion.HTTP09;


            return x;
        }

        private bool ValidateIsURI(string uri)
        {
            return Uri.IsWellFormedUriString(uri, UriKind.RelativeOrAbsolute);
        }

        private bool LoadHeaderLines()
        { //throw new NotImplementedException();
            headerLines = new Dictionary<string, string>();
            bool x = true;



            for (int i = 1; i < requestLines.Length - 1; i++)
            {
                if (requestLines[i] == "")
                    break;

                String HeaderLines = requestLines[i];
                String[] Key = HeaderLines.Split(':');  //Host:website\r\nUser-Agent: Chrome/22.0.1229.94

                headerLines.Add(Key[0], Key[1]);
            }
            if (headerLines.Count != 0)
            {
                x = true;

            }
            else
            {
                x = false;
                return x;
            }
            return x;
           
        }

        private bool ValidateBlankLine()
        {
            //throw new NotImplementedException();
            bool x = true;
            int Len = requestLines.Length - 2;
            if (requestLines[Len] == "")
            {
                x = true;

            }
            else
            {
                x = false;
                return x;
            }

            return x;
        }

    }
}
