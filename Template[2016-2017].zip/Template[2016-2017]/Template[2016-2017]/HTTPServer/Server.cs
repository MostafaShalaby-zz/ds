﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Net;
using System.Net.Sockets;
using System.Threading;
using System.IO;

namespace HTTPServer
{
    class Server
    {
        Socket serverSocket;

        public Server(int portNumber, string redirectionMatrixPath)
        {
            //TODO: call this.LoadRedirectionRules passing redirectionMatrixPath to it
            this.LoadRedirectionRules(redirectionMatrixPath);
            //TODO: initialize this.serverSocket

            IPEndPoint hostEndPoint = new IPEndPoint(IPAddress.Any, portNumber);
            //Initialize serverSocket object and bind it to local host
            serverSocket = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp);
          
            serverSocket.Bind(hostEndPoint);
        }

        public void StartServer()
        {
            /*
            // TODO: Listen to connections, with large backlog.

            // TODO: Accept connections in while loop and start a thread for each connection on function "Handle Connection"
            while (true)
            {
                //TODO: accept connections and start thread for each accepted connection.

            }
            */
            serverSocket.Listen(1000);
            while (true)
            {
                //Accept a client Socket (will block until a client connects)
                Socket clientSocket = this.serverSocket.Accept();
                Console.WriteLine("New client accepted: ");
                //RemoteEndPoint Gets the IP address and Port number of the client
                //Create a thread that works on ClientConnection.HandleConnection 	method
                Thread newthread = new Thread(new ParameterizedThreadStart
                (HandleConnection));
                //Start the thread

                newthread.Start(clientSocket);
            }

        }

        public void HandleConnection(object obj)
        {
            // TODO: Create client socket 
            // set client socket ReceiveTimeout = 0 to indicate an infinite time-out period
            Socket clientSock = (Socket)obj;
            clientSock.ReceiveTimeout = 0;
            // TODO: receive requests in while true until remote client closes the socket.
       
            int receivedLength;
            while (true)
            { try
                {   /*
                    // TODO: Receive request  -->data
                    // TODO: break the while loop if receivedLen==0
                    // TODO: Create a Request object using received request string
                    // TODO: Call HandleRequest Method that returns the response
                    // TODO: Send Response back to client               
                    */
                    byte[] data = new byte[1024];
                    receivedLength = clientSock.Receive(data);//request --> data
	                //If the message length is ZERO, means client has Closed the connection
	                //Then Close the connection with this client
	                if (receivedLength == 0)
                    {
                     Console.WriteLine("Client: {0} ended the connection ");
                     break;                
                    }

                    Request request = new Request(Encoding.ASCII.GetString(data));

                    Response response =HandleRequest(request);
                    byte[] d = new byte[1024];
                    d=Encoding.ASCII.GetBytes(response.ResponseString);

 	                //Else, display the message on the console window                                
                    //Console.WriteLine("Received: {0} from Client: {1}" ,Encoding.ASCII.GetString(d), clientSock.RemoteEndPoint);
	                //Send the message back to the client.
                    clientSock.Send(d, 0, d.Length, SocketFlags.None);
                }
                catch (Exception ex)
                {
                    // TODO: log exception using Logger class
                    Logger.LogException(ex);
                }
            }

            // TODO: close client socket
            clientSock.Close();
        }

        Response HandleRequest(Request request)
        {
            //throw new NotImplementedException();
            Response response;
            string content;
        
            //TODO: check for bad request 

            try
            {
                

               if (request.ParseRequest() == false)
                {
                    Console.WriteLine("BAD REQUEST 400");

                    response = new Response(StatusCode.BadRequest, "text.html", readcontent(Path.Combine(Configuration.RootPath, Configuration.BadRequestDefaultPageName)), null, "HTTP/1.0");

                    return response;
                }


                //TODO: map the relativeURI in request to get the physical path of the resource.
                string physical_path = Configuration.RootPath + request.relativeURI;
                //TODO: check for redirect
                string path = GetRedirectionPagePathIFExist(request.relativeURI);
                if (!path.Equals(""))
                {
                    Console.WriteLine("REDIRECTION ERROR  301");
                    response = new Response(StatusCode.Redirect, "text.html", readcontent(Path.Combine(Configuration.RootPath, Configuration.RedirectionDefaultPageName)), path, "HTTP/1.0");

                    return response;
                }
                else
                {
                    //TODO: check file exists
                    string page = getPageName(request.relativeURI);
                    string filePath = LoadDefaultPage(page);
                    if (filePath.Equals(""))
                    {
                        Console.WriteLine("PAGE NOT EXIST 404");
                        response = new Response(StatusCode.NotFound, "text.html", readcontent(Path.Combine(Configuration.RootPath, Configuration.NotFoundDefaultPageName)), null, "HTTP/1.0");

                        return response;
                    }
                    else
                    {
                        Console.WriteLine("PAGE OK");
                        response = new Response(StatusCode.OK, "text.html", readcontent(Path.Combine(Configuration.RootPath, page)), null, "HTTP/1.0");

                        return response;
                    }
                }
            }
            catch (Exception ex)
            {
                // TODO: log exception using Logger class
                Logger.LogException(ex);
                // TODO: in case of exception, return Internal Server Error. 
                Console.WriteLine(" Internal Server Error ");
                return new Response(StatusCode.InternalServerError, "text/html",
                        readcontent(Path.Combine(Configuration.RootPath, Configuration.InternalErrorDefaultPageName)), null, "HTTP/1.0");
            }
                //TODO: read the physical file

                // Create OK response//Create response Object
            
      
        }

        private string GetRedirectionPagePathIFExist(string relativePath)
        {
            // using Configuration.RedirectionRules return the redirected page path if exists else returns empty
            string pagename = getPageName(relativePath);
            bool x=Configuration.RedirectionRules.ContainsKey(pagename);//aboutus
            if (x)
            {
                     string Url;
                    Configuration.RedirectionRules.TryGetValue(pagename,out Url);//aboutus
                    return Path.Combine(Configuration.RootPath, Url);
                
            }
            return string.Empty;
        }

        private string readcontent(string path)
        {
            StreamReader sr = new StreamReader(path);
            return sr.ReadToEnd();

        }
        private string LoadDefaultPage(string defaultPageName)//load page on device
        {
        
            string filePath = Path.Combine(Configuration.RootPath, defaultPageName);
            // TODO: check if filepath not exist log exception using Logger class and return empty string
            try
            {
                if (File.Exists(filePath))
                {
                    String line; 
                    FileStream fs2 = new FileStream(filePath, FileMode.OpenOrCreate, FileAccess.Read);
                    StreamReader reader = new StreamReader(fs2);
                    List<String> lines = new List<String>();
                    while ((line = reader.ReadLine()) != null)
                    {
                        lines.Add(line);

                    }
                    return lines.ToString();
                }
            }
            catch (Exception ex)
            {
               Logger.LogException(ex);
            }
            
            // else read file and return its content


            return string.Empty;
        }

        private void LoadRedirectionRules(string filePath)
        {
            try
            {

                // TODO: using the filepath paramter read the redirection rules from file 
                Configuration.RedirectionRules = new Dictionary<string, string>();


                String line;
                FileStream fs2 = new FileStream(filePath, FileMode.OpenOrCreate, FileAccess.Read);
                StreamReader reader = new StreamReader(fs2);
                List<String> lines = new List<String>();
                while ((line = reader.ReadLine()) != null)
                {
                    lines.Add(line);

                }

                List<String> fileLines = lines;


                foreach (String linee in fileLines)
                {
                    String[] rule = linee.Split(',');
                    Configuration.RedirectionRules.Add(rule[0], rule[1]);
                }

                // then fill Configuration.RedirectionRules dictionary 

            }
            catch (Exception ex)
            {
                // TODO: log exception using Logger class
                Logger.LogException(ex);
                Environment.Exit(1);
            }
        }

        string getPageName(string relativePath)
        {
            string pagename = "";
            foreach (char x in relativePath)
            {
                if (x == '/')
                    pagename = "";
                else
                    pagename += x;
            }
            return pagename;
        }
    
    }
}
