﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SecurityLibrary
{
    class Class1
    {
        public Class1()
        {
        }

        public bool sameRow(string S, char[,] matrix)
        {
            bool D = false;

            for (int i = 0; i < 5; i++)
            {
                for (int j = 0; j < 5; j++)
                {

                    if (S[0] == matrix[i, j])
                    {
                        for (int k = 0; k < 5; k++)
                        {
                            if (S[1] == matrix[i, k])
                            {
                                return true;
                            }

                        }

                    }

                }

            }


            return D;
        }

        public bool sameCol(string S, char[,] matrix)
        {
            bool D = false;

            for (int i = 0; i < 5; i++)
            {

                for (int j = 0; j < 5; j++)
                {

                    if (S[0] == matrix[i, j])
                    {
                        for (int k = 0; k < 5; k++)
                        {
                            if (S[1] == matrix[k, j])
                            {
                                return true;
                            }

                        }

                    }

                }

            }


            return D;
        }

        public string shift_SameRow(string S, char[,] matrix)
        {
            string D = "", Y = ""; string Cipher = "";

            for (int i = 0; i < 5; i++)
            {
                for (int j = 0; j < 5; j++)
                {

                    if (S[0] == matrix[i, j])
                    {
                        if (j == 4)
                        {
                            D += matrix[i, 0];
                        }
                        else
                        {
                            D += matrix[i, j + 1];
                        }

                    }

                    if (S[1] == matrix[i, j])
                    {
                        if (j == 4)
                        {
                            Y += matrix[i, 0];
                        }
                        else
                        {
                            Y += matrix[i, j + 1];
                        }

                    }

                }
            }
            Cipher += D; Cipher += Y;

            return Cipher;

        }
        public string shift_SameCol(string S, char[,] matrix)
        {
            string D = "", Y = ""; string Cipher = "";

            for (int i = 0; i < 5; i++)
            {
                for (int j = 0; j < 5; j++)
                {
                    if (S[0] == matrix[i, j])
                    {
                        if (i == 4)
                        {
                            D += matrix[0, j];
                        }
                        else
                        {
                            D += matrix[i + 1, j];
                        }

                    }

                    if (S[1] == matrix[i, j])
                    {
                        if (i == 4)
                        {
                            Y += matrix[0, j];
                        }
                        else
                        {
                            Y += matrix[i + 1, j];
                        }

                    }
                }
            }
            Cipher += D; Cipher += Y;

            return Cipher;
        }


        public string shift_Row_Col(string S, char[,] matrix)
        {

            string D = "", Y = ""; string cipher = "";

            for (int i = 0; i < 5; i++)
            {
                for (int j = 0; j < 5; j++)
                {

                    if (S[0] == matrix[i, j])
                    {
                        for (int k = 0; k < 5; k++)
                        {
                            string str = "";
                            str += matrix[i, k]; str += S[1];
                            if (sameCol(str, matrix))
                            {
                                Y += str[0];
                            }


                        }


                    }

                    if (S[1] == matrix[i, j])
                    {
                        for (int k = 0; k < 5; k++)
                        {
                            string str = "";
                            str += S[0]; str += matrix[i, k];
                            if (sameCol(str, matrix))
                            {
                                D += str[1];

                            }

                        }


                    }
                }
            }
            cipher += Y; cipher += D;
            return cipher;


        }


        public string RetShift_Row(string S, char[,] matrix)
        {
            string D = "", Y = ""; string plain = "";

            for (int i = 0; i < 5; i++)
            {
                for (int j = 0; j < 5; j++)
                {

                    if (S[0] == matrix[i, j])
                    {
                        if (j == 0)
                        {
                            D += matrix[i, 4];
                        }
                        else
                        {
                            D += matrix[i, j - 1];
                        }

                    }

                    if (S[1] == matrix[i, j])
                    {
                        if (j == 0)
                        {
                            Y += matrix[i, 4];
                        }
                        else
                        {
                            Y += matrix[i, j - 1];
                        }

                    }

                }
            }
            plain += D; plain += Y;

            return plain.ToLower();

        }
        public string RetShift_Col(string S, char[,] matrix)
        {
            string D = "", Y = ""; string plain = "";

            for (int i = 0; i < 5; i++)
            {
                for (int j = 0; j < 5; j++)
                {
                    if (S[0] == matrix[i, j])
                    {
                        if (i == 0)
                        {
                            D += matrix[4, j];
                        }
                        else
                        {
                            D += matrix[i - 1, j];
                        }

                    }

                    if (S[1] == matrix[i, j])
                    {
                        if (i == 0)
                        {
                            Y += matrix[4, j];
                        }
                        else
                        {
                            Y += matrix[i - 1, j];
                        }

                    }
                }
            }
            plain += D; plain += Y;

            return plain.ToLower();
        }


    }
}
