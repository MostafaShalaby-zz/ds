﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SecurityLibrary.RC4
{
    /// <summary>
    /// If the string starts with 0x.... then it's Hexadecimal not string
    /// </summary>
    public class RC4 : CryptographicTechnique
    {

        public override  string Encrypt(string plainText, string key)
        {
            char[] x = new char[10];
            x[0]=plainText[0];
            x[1] = plainText[1];
            string nplain = "";
            string nkey = "";
            //byte[] str=new byte[256];
            string str = "";
             string str22 = "";
            if (x[0] == '0' && x[1] == 'x')
            {
                for (int i = 2; i < plainText.Length; i++)
                { nplain += plainText[i]; }
                str = hexToStr(nplain);

                for (int i = 2; i < key.Length; i++)
                { nkey += key[i]; }
                str22 = hexToStr(nkey);
                //plainText = str;
                string cipher = "";

                int[] S, T;

                S = new int[256];
                T = new int[256];

                for (int i = 0; i < 256; i++)
                {
                    S[i] = i;
                    T[i] = str22[i % str22.Length];
                }

                int j = 0, tmp = 0;
                for (int i = 0; i < 256; i++)
                {
                    j = (j + S[i] + T[i]) % 256;
                    tmp = S[i];
                    S[i] = S[j];
                    S[j] = tmp;
                }
                j = 0; int k = 0, tmpe = 0;
                int a = 0;
                for (int i = 0; i < str22.Length; i++)
                {
                    a++;
                    a %= 256;
                    j += S[a];
                    j %= 256;

                    tmpe = S[a];
                    S[a] = S[j];
                    S[j] = tmpe;


                  

                    k = S[((S[a] + S[j]) % 256)];
                    cipher += (char)(str[i] ^ k);

                  
                }
                string ciph = StringToHex(cipher);
                    return ("0x" + ciph);
                
            }
            else
            {
                string cipher = "";

                int[] S, T;

                S = new int[256];
                T = new int[256];

                for (int i = 0; i < 256; i++)
                {
                    S[i] = i;
                    T[i] = key[i % key.Length];
                }

                int j = 0, tmp = 0;
                for (int i = 0; i < 256; i++)
                {
                    j = (j + S[i] + T[i]) % 256;
                    tmp = S[i];
                    S[i] = S[j];
                    S[j] = tmp;
                }
                j = 0; int k = 0, tmpe = 0;
                int a = 0;
                for (int i = 0; i < key.Length; i++)
                {
                    a++;
                    a %= 256;
                    j += S[a];
                    j %= 256;

                    tmpe = S[a];
                    S[a] = S[j];
                    S[j] = tmpe;


                    k = S[((S[a] + S[j]) % 256)];
                    cipher += (char)(plainText[i] ^ k);

                }

                return cipher;
            }
        
        }

        public override string Decrypt(string cipherText, string key)
        {
            return Encrypt(cipherText,key);
        }

        private string StringToHex(string hexstring)
        {
            StringBuilder sb = new StringBuilder();
            foreach (char t in hexstring)
            {
                //Note: X for upper, x for lower case letters
                sb.Append(Convert.ToInt32(t).ToString("x"));
            }
            return sb.ToString();
        }


        private static string hexToStr(string hex)
        {
            string res = "";

            for (int i = 0; i < hex.Length; i += 2)
            {
                res += (char)Convert.ToInt32(hex.Substring(i, 2), 16);
            }

            return res;


        }

    
    }
}
