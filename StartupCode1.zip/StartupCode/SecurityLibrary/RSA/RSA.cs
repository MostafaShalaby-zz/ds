﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SecurityLibrary.RSA
{
    public class RSA
    {
        public int Encrypt(int p, int q, int M, int e)
        {
            int x = M;
            
            int C;

           int n = p * q;

           int s = (p - 1) * (q - 1);

           // double b = (double)Math.Pow(M, e);
            for (int k = 1; k < e; k++)
            {
                x *= M;
                if (x > n)
                    x = x % n;

            }
            C = x % n;

            return C;
        }

        public int Decrypt(int p, int q, int C, int e)
        {
            int d;
            int plain = 0;
            int x = C;

            int n = p * q;
            int qn = (p - 1) * (q - 1);
            d = GetMultiplicativeInverse(e, qn);


            for (int k = 1; k < d; k++)
            {
                x *= C;
                if (x > n)
                    x = x % n;

            }

            plain = x%n;

            return plain;



        }

       

        public int GetMultiplicativeInverse(int number, int baseN)
        {
            int tmp = 0;
            int bb = baseN;
            if (number < baseN)
            {
                tmp = number;
                number = baseN;
                bb = tmp;

            }
            List<int> a = new List<int>();
            List<int> b = new List<int>();
            List<int> c = new List<int>();
            int q = 0;
            a.Add(1);
            a.Add(0);
            a.Add(number);


            b.Add(0);
            b.Add(1);
            b.Add(bb);
            while (true)
            {
                if (b[2] == 0)
                { return -1; }
                else if (b[2] == 1)
                {
                    while (b[1] < 0)
                    { b[1] += baseN; }
                    return b[1];
                }
                else
                {
                    q = a[2] / b[2];

                    c.Add(a[0] - (q * b[0]));
                    c.Add(a[1] - (q * b[1]));
                    c.Add(a[2] - (q * b[2]));


                    for (int i = 0; i < 3; i++)
                    { a[i] = b[i]; }

                    for (int i = 0; i < 3; i++)
                    { b[i] = c[i]; }
                    c = new List<int>();
                }
            }

            return -1;
        }
        
		
	    


    }
}
