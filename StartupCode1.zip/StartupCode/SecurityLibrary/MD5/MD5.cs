﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SecurityLibrary.MD5
{
    public class MD5
    {
        public string GetHash(string text)
        {
            throw new NotImplementedException();
        }
    }
}
