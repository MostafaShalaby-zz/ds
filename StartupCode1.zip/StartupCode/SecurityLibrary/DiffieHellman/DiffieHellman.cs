﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SecurityLibrary.DiffieHellman
{
    public class DiffieHellman 
    {
        public List<int> GetKeys(int q, int alpha, int xa, int xb)
        {

            List<int> lis = new List<int>();
            int ya = alpha;
            for (int k = 1; k < xa; k++)
            {
                ya *= alpha;
                if (ya> q)
                    ya = ya % q;

            }


            int yb = alpha;
            for (int k = 1; k < xb; k++)
            {
                yb *= alpha;
                if (yb > q)
                    yb = yb % q;

            }


            int ka= yb;
            for (int k = 1; k < xa; k++)
            {
                ka *= yb;
                if (ka > q)
                    ka = ka % q;

            }


            int kb = ya;
            for (int k = 1; k < xb; k++)
            {
                kb *= ya;
                if (kb > q)
                    kb = kb % q;

            }


            lis.Add(ka);

            lis.Add(kb);



            return lis;
        }
    }
}
