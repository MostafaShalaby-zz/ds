﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SecurityLibrary
{
    public class AutokeyVigenere : ICryptographicTechnique<string, string>
    {
        public string Analyse(string plainText, string cipherText)
        {

            cipherText = cipherText.ToLower();
            string Alphapet = "abcdefghijklmnopqrstuvwxyz";
            string key = "";
            char[,] matrix = new char[26, 26];
            for (int i = 0; i < 26; i++)
            {
                for (int j = 0; j < 26; j++)
                {
                    matrix[i, j] = Alphapet[(i + j) % 26];
                }
            }

            for (int i = 0; i < plainText.Length; i++)
            {
                for (int j = 0; j < 26; j++)
                {
                    if (matrix[plainText[i] - 97, j] == cipherText[i])
                    {
                        key += Alphapet[j];
                    }
                }
            }
            int index = 0; string s = "";
            for (int i = 1; i < key.Length; i++)
            {
                s = key.Substring(0, i);
                if (Decrypt(cipherText, s) == plainText)
                {
                    index = i;
                    break;
                }
            }

            string x = key.Substring(0, index);


            return x;
        }

        public string Decrypt(string cipherText, string key)
        {
            cipherText = cipherText.ToLower();
            string Alphapet = "abcdefghijklmnopqrstuvwxyz";
            char[,] matrix = new char[26, 26];
            for (int i = 0; i < 26; i++)
            {
                for (int j = 0; j < 26; j++)
                {
                    matrix[i, j] = Alphapet[(i + j) % 26];
                }
            }

            string plaintext = "";
            for (int i = 0; i < cipherText.Length; i++)
            {
                for (int j = 0; j < 26; j++)
                {
                    if (matrix[key[i] - 97, j] == cipherText[i])
                    {
                        plaintext += Alphapet[j];
                        key += Alphapet[j];
                    }
                }

            }

            return plaintext;

        }

        public string Encrypt(string plainText, string key)
        {

            string Alphapet = "abcdefghijklmnopqrstuvwxyz";
            char[,] matrix = new char[26, 26];
            for (int i = 0; i < 26; i++)
            {
                for (int j = 0; j < 26; j++)
                {
                    matrix[i, j] = Alphapet[(i + j) % 26];
                }
            }
            key += plainText;

            String Cipher1 = "";
            for (int i = 0; i < plainText.Length; i++)
            {
                int x1 = plainText[i] - 97;
                int x2 = key[i] - 97;

                Cipher1 += matrix[x1, x2];
            }
            string s = Cipher1.ToUpper();

            return s;
        }
    }
}
