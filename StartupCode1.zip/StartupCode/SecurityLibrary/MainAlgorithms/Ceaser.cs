﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SecurityLibrary
{
    public class Ceaser : ICryptographicTechnique<string, int>
    {
        public string Encrypt(string plainText, int key)
        {
            String str = "";
                  
            for (int i = 0; i < plainText.Length; i++)
            {


                str += (char)(97 + (((int)plainText[i] - 97 + key) % 26));


            }


            return str.ToUpper();

        }

        public string Decrypt(string cipherText, int key)
        {

            string Alphapet = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";

            String plainText2 = "";


            for (int i = 0; i < cipherText.Length; i++)
            {

                string s = cipherText[i].ToString();
                int index = Alphapet.IndexOf(s.ToUpper());
                if (index - key < 0)
                {
                    int z = (index - key) + 26;
                    plainText2 += Alphapet[z];
                }
                else
                {
                    plainText2 += Alphapet[index - key];
                }



            }

            String Sa = plainText2.ToLower();
            
            return Sa;
            
        }

        public int Analyse(string plainText, string cipherText)
        {
            string Alphapet = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
            int[] Vosoted = new int[plainText.Length];
            for (int k = 0; k < plainText.Length; k++)
            {


                string gd = plainText[k].ToString(); int ind = Alphapet.IndexOf(gd.ToUpper());
                string ds = cipherText[k].ToString(); int inde2 = Alphapet.IndexOf(ds.ToUpper());
                

                int count3 = 1; bool w = false;


                for (int i = ind + 1; i < Alphapet.Length; i++)
                {

                    if (ds[0] == Alphapet[i])
                    {
                        w = true;
                        break;
                    }
                    count3++;
                }
                if (w == false)
                {
                    for (int j = 0; j < ind; j++)
                    {
                        if (ds[0] == Alphapet[j])
                        {
                            w = true;
                            break;
                        }
                        count3++;
                    }
                }

                Vosoted[k] = count3;
                count3 = 1;
                w = false;

            }
            if (plainText.Equals(cipherText.ToLower()))
            {
                return 0;
            }
            else
            {
                return Vosoted[0];
            }
            

        }
    }
}
