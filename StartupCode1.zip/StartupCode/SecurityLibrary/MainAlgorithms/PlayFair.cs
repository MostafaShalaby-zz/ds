﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SecurityLibrary
{
    public class PlayFair : ICryptographicTechnique<string, string>
    {
        public string Decrypt(string cipherText, string key)
        {
            Class1 clas = new Class1();
            string Alphapet = "ABCDEFGHIKLMNOPQRSTUVWXYZ";
            List<char> Vis = new List<char>();
            string mainKey1 = key.ToUpper();

            for (int i = 0; i < mainKey1.Length; i++)
            {
                if (Vis.Contains(mainKey1[i]))
                    continue;

                Vis.Add(mainKey1[i]);
            }

            for (int i = 0; i < Alphapet.Length; i++)
            {
                if (Vis.Contains(Alphapet[i]))
                    continue;

                Vis.Add(Alphapet[i]);
            }



            int C = 0;
            char[,] matrix = new char[5, 5];
            for (int i = 0; i < 5; i++)
            {
                for (int j = 0; j < 5; j++)
                {

                    matrix[i, j] = Vis[C++];

                }

            }

            string[] Diagram2 = new string[cipherText.Length / 2];

            int coun2 = 0; int d2 = 0;

            for (int i = 0; i < cipherText.Length; i++)
            {

                coun2++;
                if (coun2 == 2)
                {

                    Diagram2[d2] += cipherText[i - 1];
                    Diagram2[d2] += cipherText[i];
                    coun2 = 0;
                    d2++;
                }
            }


            string plain = "";
            foreach (string j in Diagram2)
            {
                if (clas.sameRow(j, matrix))
                {
                    plain += clas.RetShift_Row(j, matrix);
                }
                else if (clas.sameCol(j, matrix))
                {
                    plain += clas.RetShift_Col(j, matrix);
                }
                else
                {
                    plain += clas.shift_Row_Col(j, matrix);
                }


            }
            string y = plain.ToLower(); string t = "";

            for (int i = 0; i < y.Length; i++)
            {

                if (y[i] == 'x')
                    continue;

                t += y[i];


            }

            return t;
            
        }

        public string Encrypt(string plainText, string key)
        {
            Class1 clas = new Class1();
            string Alphapet = "ABCDEFGHIKLMNOPQRSTUVWXYZ";
            List<char> Vis = new List<char>();
            string mainKey1 = key.ToUpper();

            for (int i = 0; i < mainKey1.Length; i++)
            {
                if (Vis.Contains(mainKey1[i]))
                    continue;

                Vis.Add(mainKey1[i]);
            }

            for (int i = 0; i < Alphapet.Length; i++)
            {
                if (Vis.Contains(Alphapet[i]))
                    continue;

             
                Vis.Add(Alphapet[i]);
            }


            
            int C = 0;
            char[,] matrix=new char[5,5];
            for (int i = 0; i < 5; i++)
            {
                for (int j = 0; j < 5; j++)
                {

                    matrix[i, j] = Vis[C++];

                }

            }

            int coun = 0;
             List<char> Visited = new List<char>();
            for (int i = 0; i < plainText.Length; i++)
            {

                coun++;
                if (coun == 2)
                {
                    if (plainText[i - 1] == plainText[i])
                    {
                        
                        Visited.Add(plainText[i]);
                    }
                    coun = 0;
                }
            }


            string Str = "";
            for (int i = 0; i < plainText.Length; i++)
            {
                if (i + 1 < plainText.Length)
                {
                    if (plainText[i] == plainText[i + 1] && Visited.Contains(plainText[i]))
                    {
                        Str += plainText[i];
                        Str += 'x';
                        Str += plainText[i + 1];
                        i++;

                    }
                    else
                    {
                        Str += plainText[i];
                    }

                }
                else
                {
                    Str += plainText[i];
                    break;
                }

            }
            plainText = Str;
            if (plainText.Length % 2 == 1)
            {
                plainText += "x";

            }




            string[] Diagram = new string[plainText.Length / 2];

            int coun2 = 0; int d = 0;
            for (int i = 0; i < plainText.Length; i++)
            {

                coun2++;
                if (coun2== 2)
                {

                    Diagram[d] += plainText[i - 1];
                    Diagram[d] += plainText[i];
                    coun2 = 0;
                    d++;
                }
            }

            string Cipher = "";
            foreach (string s in Diagram)
            {
                if (clas.sameRow(s.ToUpper(), matrix))
                {
                    Cipher += clas.shift_SameRow(s.ToUpper(), matrix);
                }
                else if (clas.sameCol(s.ToUpper(), matrix))
                {
                    Cipher += clas.shift_SameCol(s.ToUpper(), matrix);
                }
                else
                {
                    Cipher += clas.shift_Row_Col(s.ToUpper(), matrix);
                }
         }

            return Cipher.ToUpper();

        }
		//not required
		public string Analyse(string plainText, string cipherText)
        {
            throw new NotSupportedException();
        }
    }
}
