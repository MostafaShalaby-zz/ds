﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SecurityLibrary
{
    public class Monoalphabetic : ICryptographicTechnique<string, string>
    {
        public string Analyse(string plainText, string cipherText)
        {
            cipherText = cipherText.ToLower();
            var c_t = cipherText.ToCharArray();
            var p_t = plainText.ToCharArray();
            char[] key = new char[26];
            char[] notvisited = new char[26];
            for (int i = 0; i < c_t.Length; i++)
            {
                char c = p_t[i];
                int index1 = c - 97;
                key[index1] = c_t[i];
            }
            int f = 0;
            for (int i = 0; i < 26; i++)
            {

                int g = 97 + i;
                char x = (char)g;
                bool t = key.Contains(x);
                if (t == false)
                {
                    notvisited[f] = x;
                    f++;
                }
            }
            int n = 0;
            for (int i = 0; i < key.Length; i++)
            {

                if (key[i] == '\0')
                {

                    key[i] = notvisited[n];
                    n++;
                }
            }
            return new string(key);
        }

        public string Decrypt(string cipherText, string key)
        {

            cipherText = cipherText.ToLower();
            var c_t = cipherText.ToCharArray();

            var k = key.ToCharArray();
            char[] p_t = new char[cipherText.Length];

            for (int i = 0; i < c_t.Length; i++)
            {
                char c = c_t[i];

                // int index;   //index in key 
                // int index1=  k.Select((car, index) => new { car, index }).First(car =>car = c).index;
                int index1 = key.IndexOf(c);
                // index1++;
                index1 += 97;
                p_t[i] = (char)index1;

            }
            return new string(p_t);

        }

        public string Encrypt(string plainText, string key)
        {

            //string key1 = "DQEPRSFTAWXUGOBVHNCMIZLYJK";
            var key1 = key.ToCharArray();
            char[] c_t = new char[plainText.Length];
            int index = 0;
            var p_t = plainText.ToCharArray();
            for (int i = 0; i < p_t.Length; i++)
            {
                index = p_t[i] - 97;
                char c;
                c = key1[index];
                c_t[i] = c;

            }
            return new string(c_t);  
        }

        /// <summary>
        /// Frequency Information:
        /// E   12.51%
        /// T	9.25
        /// A	8.04
        /// O	7.60
        /// I	7.26
        /// N	7.09
        /// S	6.54
        /// R	6.12
        /// H	5.49
        /// L	4.14
        /// D	3.99
        /// C	3.06
        /// U	2.71
        /// M	2.53
        /// F	2.30
        /// P	2.00
        /// G	1.96
        /// W	1.92
        /// Y	1.73
        /// B	1.54
        /// V	0.99
        /// K	0.67
        /// X	0.19
        /// J	0.16
        /// Q	0.11
        /// Z	0.09
        /// </summary>
        /// <param name="cipher"></param>
        /// <returns>Plain text</returns>
        public string AnalyseUsingCharFrequency(string cipher)
        {
            cipher = cipher.ToLower();
            string Freqency = "etaoinsrlhdcmpuwfgybvkjxqz";   //kda da frequency descending

            string cipher_dist = new String(cipher.Distinct().ToArray());

            int[] cp = new int[cipher_dist.Length];

            for (int i = 0; i < cipher.Length; i++)
            {
                for (int j = 0; j < cipher_dist.Length; j++)
                {
                    if (cipher[i] == cipher_dist[j])
                    {
                        cp[j]++;
                        break;
                    }
                }
            }
            List<KeyValuePair<char, int>> alpha = new List<KeyValuePair<char, int>>();
            for (int indx = 0; indx < cipher_dist.Length; indx++)
            {
                alpha.Add(new KeyValuePair<char, int>(cipher_dist[indx], cp[indx]));
            }

            alpha = alpha.OrderBy(x => x.Value).ToList();
            string plain_text = "";
            for (int i = 0; i < cipher.Length; i++)
            {
                int pos = alpha.FindIndex(x => x.Key == cipher[i]);
                plain_text += Freqency[25 - pos];

            }
            return plain_text;
        }
    }
}
