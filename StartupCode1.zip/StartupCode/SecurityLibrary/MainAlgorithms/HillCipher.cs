﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SecurityLibrary
{
    /// <summary>
    /// The List<int> is row based. Which means that the key is given in row based manner.
    /// </summary>
    public class HillCipher : ICryptographicTechnique<List<int>, List<int>>
    {
        public List<int> Analyse(List<int> plainText, List<int> cipherText)
        {
            throw new NotImplementedException();
        }


        public List<int> Decrypt(List<int> cipherText, List<int> key)
        {
            throw new NotImplementedException();
        }


        public List<int> Encrypt(List<int> plainText, List<int> key)
        {
            int C = 0;

            double ss = Math.Sqrt(key.Count);
            int size = int.Parse(ss.ToString());

            int siz = (plainText.Count / size);

            List<int> k = new List<int>();
            int[,] matrix = new int[size, size];
            int[,] m2 = new int[size, siz];
            int[,] Res = new int[size, siz];

            for (int i = 0; i < size; i++)
            {
                for (int j = 0; j < size; j++)
                {

                    matrix[i, j] = key[C++];

                }

            }
            C = 0;

            for (int i = 0; i < siz; i++)
            {
                for (int j = 0; j < size; j++)
                {

                    m2[j, i] = plainText[C++];

                }

            }

            int sum = 0;

            for (int i = 0; i < size; i++)
                for (int j = 0; j < siz; j++)
                    Res[i, j] = 0;
            for (int i = 0; i < size; i++)    //row of first matrix
            {
                for (int j = 0; j < siz; j++)    //column of second matrix
                {
                    sum = 0;
                    for (int k1 = 0; k1 < size; k1++)
                        sum = sum + matrix[i, k1] * m2[k1, j];
                    Res[i, j] = sum % 26;
                }
            }


            List<int> Cipher = new List<int>();

            for (int i = 0; i < siz; i++)
            {
                for (int j = 0; j < size; j++)
                {

                    Cipher.Add(Res[j, i]);

                }

            }

            return Cipher;

        }


        public List<int> Analyse3By3Key(List<int> plainText, List<int> cipherText)
        {
            throw new NotImplementedException();
        }
    }
}
