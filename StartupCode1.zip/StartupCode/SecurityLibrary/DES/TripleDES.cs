﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SecurityLibrary.DES
{
    /// <summary>
    /// If the string starts with 0x.... then it's Hexadecimal not string
    /// </summary>
    public class TripleDES : ICryptographicTechnique<string, List<string>>
    {
        
        public string Decrypt(string cipherText, List<string> key)
        {
            
            DES d = new DES();
            string c1 = d.Decrypt(cipherText, key[0]);
            string c2 = d.Encrypt(c1, key[1]);
            c1 = d.Decrypt(c2, key[0]);

            return c1;
        }

        public string Encrypt(string plainText, List<string> key)
        {
            DES d = new DES();

            string c1 = d.Encrypt(plainText,key[0]);
            string c2 = d.Decrypt(c1,key[1]);
            c1 = d.Encrypt(c2,key[0]);

            return c1;

            
        }

        public List<string> Analyse(string plainText,string cipherText)
        {
            throw new NotSupportedException();
        }

    }
}
