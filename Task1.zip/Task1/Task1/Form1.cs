using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using ESRI.ArcGIS.Carto;
using ESRI.ArcGIS.Geometry;

namespace Task1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        
        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

            
            IMapDocument dm = new MapDocument();
            dm.Open("G:\\mahmoud.mxd");
            for (int i = 0; i < dm.MapCount; i++)
            {
                if (comboBox1.SelectedIndex == i)
                {
                    checkedListBox1.Items.Clear();
                    IMap map = dm.get_Map(i);
                    axMapControl1.Map = map;
                    axMapControl1.Refresh();
                    for (int j = 0; j < map.LayerCount; j++)
                    {
                        ILayer layer = dm.get_Map(comboBox1.SelectedIndex).get_Layer(j);

                        checkedListBox1.Items.Add(layer.Name);
                    }
                }
            }
                
            axMapControl1.Extent = axMapControl1.FullExtent;
            axMapControl1.Refresh();

            for (int i = 0; i < checkedListBox1.Items.Count; i++)
            {
                checkedListBox1.SetItemChecked(i, true);
            }
        }

        private void axMapControl1_OnMouseMove(object sender, ESRI.ArcGIS.Controls.IMapControlEvents2_OnMouseMoveEvent e)
        {
            statusBar1.Panels[0].Text = e.mapX+"  "+e.mapY+"  Meters";
        }

        private void checkedListBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            IMapDocument dm = new MapDocument();
            dm.Open("G:\\mahmoud.mxd");
           
          
                IMap map = dm.get_Map(comboBox1.SelectedIndex);

               
                    for (int j = 0; j < checkedListBox1.Items.Count; j++)
                    {
                      //  ILayer l = map.get_Layer(j);
                        if (checkedListBox1.GetItemChecked(j).Equals(false))
                        {
                          //  l.Visible = false;
                            map.get_Layer(j).Visible = false;
                            axMapControl1.Map = map;
                            axMapControl1.Refresh();
                        }
                        else if (checkedListBox1.GetItemChecked(j).Equals(true))
                        {
                            map.get_Layer(j).Visible = true;
                            axMapControl1.Map = map;
                            axMapControl1.Refresh();
                        }
                    }
                
            

            axMapControl1.Extent = axMapControl1.FullExtent;
            axMapControl1.Refresh();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            IMapDocument dm = new MapDocument();
            dm.Open("G:\\mahmoud.mxd");
            for (int i = 0; i < dm.MapCount; i++)
            {
                comboBox1.Items.Add(dm.get_Map(i).Name);
            }
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            axMapControl1.MapScale = axMapControl1.MapScale - axMapControl1.MapScale / 50;
            axMapControl1.Refresh();
        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {
            axMapControl1.MapScale = axMapControl1.MapScale + axMapControl1.MapScale / 50;
            axMapControl1.Refresh();
        }

        private void pictureBox3_Click(object sender, EventArgs e)
        {
            axMapControl1.Extent = axMapControl1.FullExtent;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            

            OpenFileDialog dialog = new OpenFileDialog();
            string filename = "";

            if (dialog.ShowDialog()==DialogResult.OK)
            {
                filename = dialog.FileName;
            }

            IMapDocument dm = new MapDocument();
            dm.Open(filename);
            for (int i = 0; i < dm.MapCount; i++)
            {
                comboBox1.Items.Add(dm.get_Map(i).Name);
            }

        }

     
    }
}